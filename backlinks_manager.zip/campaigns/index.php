<?php
header("Location: campaign_management.php");
exit;
