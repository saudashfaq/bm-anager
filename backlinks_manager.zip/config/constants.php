<?php

$campaign_frequency = [
    'daily' => 'Daily',
    'weekly' => 'Weekly',
    'every_two_weeks' => 'Every Two Weeks',
    'monthly' => 'Monthly'
];

$campaign_statuses = [
    'enabled' => ['value' => 'enabled', 'label' => 'Active'],
    'disabled' => ['value' => 'disabled', 'label' => 'Inactive'],
];
