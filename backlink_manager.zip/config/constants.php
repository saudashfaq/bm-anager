<?php

$campaign_frequency = [
    'daily' => 'Daily',
    'weekly' => 'Weekly',
    'every_two_weeks' => 'Every Two Weeks',
    'monthly' => 'Monthly'
];
