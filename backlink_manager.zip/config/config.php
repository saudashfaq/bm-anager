<?php
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', 'root');
define('DB_NAME', 'backlinks_manager');
define('SITE_URL', 'https://example.com');
define('BASE_URL', '/backlinks_manager/'); // Ensure the trailing slash is present

